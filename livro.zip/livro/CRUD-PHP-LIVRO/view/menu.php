<hr>
<a href="index.php" class="btn btn-default">Inicio</a>
<a href="cadastro.php" class="btn btn-success">Cadastar</a>
<hr>
